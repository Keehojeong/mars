<?php
$connect = mysqli_connect("211.218.150.109", "ci2020mars", "2020mars") or die("SQL Server에 연결할 수 없습니다.");

mysqli_query("SET NAMES UTF8");
mysqli_select_db("ci2020mars", $connect);

session_start();

$sql = "select * from Rescue";
$result = mysqli_query($sql, $connect);
$total_record = mysqli_num_rows($result);

echo "{\"status\":\"OK\",\"num_results\":\"$total_record\",\"results\":[";

for ($i = 0; $i < $total_record; $i ++) {
    mysqli_data_seek($result, $i);
    $row = mysqli_fetch_array($result);
    echo "{\"r_id\":$row[r_id],\"r_lat\":$row[r_lat],\"r_lng\":$row[r_lng],\"r_heart\":$row[r_heart]\"}";

    if ($i < $total_record - 1) {
        echo ",";
    }
}
echo "]}";
?>
