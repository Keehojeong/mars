<?php
$con = mysqli_connect("211.218.150.109","ci2020remi","2020remi", "ci2020remi","3306" );
mysqli_query($con,'SET NAMES utf8');

$userid = $_POST["userid"];
$username = $_POST["username"];
$email = $_POST["email"];
$password = $_POST["password"];
$userphone = $_POST["userphone"];
$userbirth = $_POST["userbirth"];

$statement = mysqli_prepare($con, "INSERT INTO article VALUES (?,?,?,?,?,?)");
mysqli_stmt_bind_param($statement, "sssiis", $userid, $username, $email, $password, $userphone, $userbirth);
mysqli_stmt_execute($statement);


$response = array();
$response["success"] = true;


echo json_encode($response);
?>